<?php

$MESS ['MCART_XLS_HANDLER_DATE'] = "Дата";

$MESS ['MCART_XLS_HANDLER_DATETIME'] = "Дата со временем";

$MESS ['MCART_XLS_HANDLER_PICTURE'] = "Картинка";

$MESS ['MCART_XLS_HANDLER_URL'] = "Ссылка";
$MESS ['MCART_XLS_HANDLER_URL__TEST_REQUIRED'] = "Тест (обязат.)";
$MESS ['MCART_XLS_HANDLER_URL__TEST'] = "Тест";
$MESS ['MCART_XLS_HANDLER_URL__TEST_LIST_REQUIRED'] = "Тест списка (обязат.)";
$MESS ['MCART_XLS_HANDLER_URL__TEST_LIST'] = "Тест списка";
