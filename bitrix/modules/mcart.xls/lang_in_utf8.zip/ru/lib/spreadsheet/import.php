<?
$MESS ['MCART_XLS_IMPORT_COMPLETED'] = "Импорт завершён";
$MESS ['MCART_XLS_IMPORT_ERROR__PROFILE_ID_0'] = 'Профиль не указан';
$MESS ['MCART_XLS_IMPORT_ERROR__PROFILE_NOT_FOUND'] = 'Профиль не найден';
$MESS ['MCART_XLS_IMPORT_ERROR__PROFILE_COLUMNS_NOT_FOUND'] = 'Сопоставления столбцов не найдены';
$MESS ['MCART_XLS_IMPORT_ERROR__PROFILE_IDENTIFY_ELEMENT_NOT_FOUND'] = 'Ни одно из сопоставлений столбцов не было отмечено как "Уникальный идентификатор элемента"';
