<?
$MESS ['MCART_XLS_PROFILE_ID'] = "ID профиля";
$MESS ['MCART_XLS_PROFILE_NAME'] = "Название профиля";
$MESS ['MCART_XLS_PROFILE_FILE'] = "Файл";
$MESS ['MCART_XLS_PROFILE_FILE_HEADERS'] = "Заголовки из файла";
$MESS ['MCART_XLS_PROFILE_MAIL_FILTER_ID'] = "Правило обработки почты";
$MESS ['MCART_XLS_PROFILE_IBLOCK_ID'] = "ID инфо-блока";

$MESS ['MCART_XLS_PROFILE_QUANTITY_ELEMENTS_IMPORTED_PER_STEP'] = "Кол-во элементов, обрабатываемых за шаг импорта";

$MESS ['MCART_XLS_PROFILE_ONLY_UPDATE'] = "Элементы только обновлять (не создавать)";

$MESS ['MCART_XLS_PROFILE_DEACTIVATE_IF_NEW'] = "Деактивировать новые элементы";
$MESS ['MCART_XLS_PROFILE_SKU_CODE'] = "Код торгового предложения";
$MESS ['MCART_XLS_PROFILE_DEACTIVATE_IF_QUANTITY_0'] = "Деактивировать элемент, если товара нет в наличии";
$MESS ['MCART_XLS_PROFILE_DEACTIVATE_IF_PRICE_0'] = "Деактивировать элемент, если цена нулевая";
$MESS ['MCART_XLS_PROFILE_DEACTIVATE_ELEMENT_IF_NOT_IN_FILE'] = "Деактивировать отсутствующие в файле элементы (пока не реализовано)";

$MESS ['MCART_XLS_PROFILE_ACTIVATE_IF_QUANTITY_AND_PRICE_NOT_0'] = "Активировать элемент, если цена НЕ нулевая и товар в наличии";

$MESS ['MCART_XLS_PROFILE_IBLOCK_SECTION_ID_FOR_NEW'] = "ID раздела для новых элементов инфо-блока (по умолчанию корень)";

$MESS ['MCART_XLS_PROFILE_HEADER_ROW'] = "Строка с заголовками";
$MESS ['MCART_XLS_PROFILE_START_ROW'] = "Первая строка с данными";
$MESS ['MCART_XLS_PROFILE_END_ROW'] = "Крайняя строка с данными";
