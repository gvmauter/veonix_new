<?
$MESS ['MCART_XLS_PROFILE_CONST_PROFILE_ID'] = "ID профиля";
$MESS ['MCART_XLS_PROFILE_CONST_SAVE_IN_PREF'] = "Место хранения значения (поле, свойство, каталог и пр.)";
$MESS ['MCART_XLS_PROFILE_CONST_SAVE_IN'] = "Поле/свойство элемента/товара";
$MESS ['MCART_XLS_PROFILE_CONST_VALUE'] = "Константа";


