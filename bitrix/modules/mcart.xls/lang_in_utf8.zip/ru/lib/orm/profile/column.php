<?
$MESS ['MCART_XLS_PROFILE_COLUMN_PROFILE_ID'] = "ID профиля";
$MESS ['MCART_XLS_PROFILE_COLUMN_COLUMN'] = "Столбец в файле";
$MESS ['MCART_XLS_PROFILE_COLUMN_SAVE_IN_PREF'] = "Место хранения значения (поле, свойство, каталог и пр.)";
$MESS ['MCART_XLS_PROFILE_COLUMN_SAVE_IN'] = "Поле/свойство элемента";
$MESS ['MCART_XLS_PROFILE_COLUMN_HANDLER'] = "Преобразование";
$MESS ['MCART_XLS_PROFILE_COLUMN_DO_NOT_IMPORT_ROW_IF_EMPTY'] = "Не импортировать строку, если эта ячейка пуста";
$MESS ['MCART_XLS_PROFILE_COLUMN_IS_IDENTIFY_ELEMENT'] = "Уникальный идентификатор элемента";
