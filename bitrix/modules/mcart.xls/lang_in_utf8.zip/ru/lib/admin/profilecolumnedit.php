<?
$MESS ['MCART_XLS_TITLE_PREF'] = "Сопоставление к профилю";
$MESS ['MCART_XLS_CUSTOM_FIELDS_HEAD'] = "Доп. параметры";
$MESS ['MCART_XLS_CUSTOM_FIELDS_HEAD_TOOLTIP'] = "будут переданы в обработчики событий";
