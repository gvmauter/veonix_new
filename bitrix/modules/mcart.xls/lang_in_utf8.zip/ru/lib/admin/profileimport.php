<?
$MESS ['MCART_XLS_TITLE_PREF'] = "Импорт по профилю";
$MESS ['MCART_XLS_IMPORT__PROCESSED_ROWS'] = "Обработано строк";
$MESS ['MCART_XLS_IMPORT__ADDED_ELEMENTS'] = "Добавлено элементов";
$MESS ['MCART_XLS_IMPORT__UPDATED_ELEMENTS'] = "Обновлено элементов";
$MESS ['MCART_XLS_PROFILE_ERROR_FILE'] = "Укажите файл *.xlsx";