<?
$MESS ['MCART_XLS_TITLE_PREF'] = "Сопоставления к профилю";
