<?
$MESS['MCART_XLS__PROFILE__USERS_GROUPS'] = "Упрощенный режим для групп";
$MESS['MCART_XLS__PROFILE__USERS_GROUPS_TOOLTIP'] = "Для указанных групп пользователей предустановить нижеследующие параметры, и не давать их менять";
$MESS['MCART_XLS__PROFILE__END_ROW_TOOLTIP'] = "Если не указано, до конца листа";


