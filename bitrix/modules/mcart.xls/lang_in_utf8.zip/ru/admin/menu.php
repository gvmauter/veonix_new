<?
$MESS ['MCART_XLS_TITLE'] = "Импорт из Excel";
