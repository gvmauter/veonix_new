<?
$MESS ['MCART_XLS_PROFILE_REQUIRED_FIELDS'] = "Поля, обязательные для заполнения выделены <b>жирным</b>";

$MESS ['MCART_XLS_PROFILE_END_ROW_TOOLTIP'] = "Если не указано, до конца листа";

$MESS ['MCART_XLS_PROFILE_ACTIVATE_IF_QUANTITY_AND_PRICE_NOT_0_TOOLTIP'] = "Активировать элемент, если цена НЕ нулевая и товар в наличии (т. е. количество больше нуля или выключен количественный учет)";
$MESS ['MCART_XLS_PROFILE_DEACTIVATE_IF_QUANTITY_0_TOOLTIP'] = "Т. е., если количество нулевое и включен количественный учет";

$MESS ['MCART_XLS_PROFILE_STEP1_HEAD3'] = "Константы";
$MESS ['MCART_XLS_PROFILE_STEP1_CONST_HEAD1'] = "Константа";
$MESS ['MCART_XLS_PROFILE_STEP1_CONST_HEAD2'] = "Поле/свойство инфо-блока";

$MESS ['MCART_XLS_PROFILE_NEXT'] = "Далее";
$MESS ['MCART_XLS_PROFILE_CANCEL'] = "Отмена";

$MESS ['MCART_XLS_PROFILE_ERROR_NAME'] = "Укажите название";
$MESS ['MCART_XLS_PROFILE_ERROR_FILE'] = "Укажите файл *.xlsx";
$MESS ['MCART_XLS_PROFILE_ERROR_IBLOCK_ID'] = "Укажите инфо-блок";