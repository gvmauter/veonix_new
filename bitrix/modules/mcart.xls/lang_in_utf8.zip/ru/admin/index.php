<?
$MESS ['MCART_XLS_COL_NAME'] = "Название профиля";
$MESS ['MCART_XLS_COL_IBLOCK'] = "Инфо-блок";
