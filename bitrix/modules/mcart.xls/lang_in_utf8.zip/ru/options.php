<?
$MESS["MCART_XLS__OPTIONS__SAVE"] = "Сохранить";
$MESS["MCART_XLS__OPTIONS__RESET"] = "Сбросить";
$MESS["MCART_XLS__OPTIONS__RESTORE_DEFAULTS"] = "По умолчанию";
$MESS['MCART_XLS__OPTIONS__HINT_RESTORE_DEFAULTS_WARNING'] = "Внимание! Все настройки будут перезаписаны значениями по умолчанию. Продолжить?";