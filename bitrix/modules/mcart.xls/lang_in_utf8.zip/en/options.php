﻿<?
$MESS["MCART_XLS__OPTIONS__SAVE"] = "Save";
$MESS["MCART_XLS__OPTIONS__RESET"] = "Reset";
$MESS["MCART_XLS__OPTIONS__RESTORE_DEFAULTS"] = "Default";
$MESS['MCART_XLS__OPTIONS__HINT_RESTORE_DEFAULTS_WARNING'] = "Attention! All settings will be overwritten with the default values. Continue?";