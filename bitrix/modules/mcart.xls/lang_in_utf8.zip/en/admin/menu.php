﻿<?
$MESS ['MCART_XLS_TITLE'] = "Import from Excel";
