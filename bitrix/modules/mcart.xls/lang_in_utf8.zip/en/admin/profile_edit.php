<?
$MESS ['MCART_XLS_PROFILE_REQUIRED_FIELDS'] = "Required fields are highlighted in <b>bold</b>";

$MESS ['MCART_XLS_PROFILE_END_ROW_TOOLTIP'] = "If not specified, to the end of the sheet";

$MESS ['MCART_XLS_PROFILE_ACTIVATE_IF_QUANTITY_AND_PRICE_NOT_0_TOOLTIP'] = "Activate the item if the price is not zero and the product is in stock (that is, the quantity is greater than zero or stock control is disabled)";
$MESS ['MCART_XLS_PROFILE_DEACTIVATE_IF_QUANTITY_0_TOOLTIP'] = "That is, if the number is zero and stock control is enable";

$MESS ['MCART_XLS_PROFILE_STEP1_HEAD3'] = "Constants";
$MESS ['MCART_XLS_PROFILE_STEP1_CONST_HEAD1'] = "Constant";
$MESS ['MCART_XLS_PROFILE_STEP1_CONST_HEAD2'] = "Field/property of the infoblock";

$MESS ['MCART_XLS_PROFILE_NEXT'] = "Next";
$MESS ['MCART_XLS_PROFILE_CANCEL'] = "Cancel";

$MESS ['MCART_XLS_PROFILE_ERROR_NAME'] = "Specify the name";
$MESS ['MCART_XLS_PROFILE_ERROR_FILE'] = "Specify the file *.xlsx";
$MESS ['MCART_XLS_PROFILE_ERROR_IBLOCK_ID'] = "Specify the infoblock";
