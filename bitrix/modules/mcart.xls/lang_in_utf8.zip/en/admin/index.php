﻿<?
$MESS ['MCART_XLS_COL_NAME'] = "Profile name";
$MESS ['MCART_XLS_COL_IBLOCK'] = "Infoblock";
