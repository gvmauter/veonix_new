﻿<?php
$MESS['MCART_XLS_TITLE'] = "Import from Excel";
$MESS['MCART_XLS_REQUIREMENTS_ERROR'] = 'The following module requirements are not met "#MODULE_ID#": #REQUIREMENTS#';
$MESS['MCART_XLS_PROFILE_COLUMNS'] = 'Column mappings';
$MESS['MCART_XLS_PROFILE'] = 'Profile';
$MESS['MCART_XLS_PROFILE_ADD'] = 'New import profile';
$MESS['MCART_XLS_TO_IMPORT'] = 'Import';
$MESS["MCART_XLS_LIST_EMPTY"] = "Not selected";

$MESS['MCART_XLS_EDIT'] = 'Edit';
$MESS['MCART_XLS_DELETE'] = "Delete";
$MESS['MCART_XLS_ADD'] = "Add";
$MESS['MCART_XLS_SAVE'] = "Save";
$MESS['MCART_XLS_CANCEL'] = "Cancel";
$MESS['MCART_XLS_BACK'] = "Back";
$MESS['MCART_XLS_REQUIRED_FIELDS'] = "Required fields are marked in <b>bold</b>";
$MESS['MCART_XLS_OR'] = 'or';

$MESS ['MCART_XLS_REQUIREMENT_CHECK'] = "Autocheck";
$MESS ['MCART_XLS_REQUIREMENT_CHECK_PASSED'] = "Check is passed";
$MESS ['MCART_XLS_REQUIREMENT_CHECK_FAILED'] = "Check is failed";

$MESS ['MCART_XLS_FIELDS'] = "Infoblock elements fields";
$MESS ['MCART_XLS_FIELDS_SHORT'] = "Infoblock fields";
$MESS ['MCART_XLS_PROPERTIES'] = "Infoblock elements properties";
$MESS ['MCART_XLS_PROPERTIES_SHORT'] = "Infoblock properties";
$MESS ['MCART_XLS_CATALOG'] = "Trading catalog";
$MESS ['MCART_XLS_CATALOG_SHORT'] = "Trade.catalog";
$MESS ['MCART_XLS_FIELD_ID'] = "ID (read only)";
$MESS ['MCART_XLS_FIELD_CODE'] = "Symbolic code";
$MESS ['MCART_XLS_FIELD_XML_ID'] = "External code";
$MESS ['MCART_XLS_FIELD_NAME'] = "Element name";
$MESS ['MCART_XLS_FIELD_SORT'] = "Sort";
$MESS ['MCART_XLS_FIELD_PREVIEW_PICTURE'] = "Preview picture";
$MESS ['MCART_XLS_FIELD_PREVIEW_TEXT'] = "Preview text";
$MESS ['MCART_XLS_FIELD_DETAIL_PICTURE'] = "Detailed picture";
$MESS ['MCART_XLS_FIELD_DETAIL_TEXT'] = "Detailed description";
$MESS ['MCART_XLS_CATALOG_QUANTITY'] = "Quantity of goods in stock";
$MESS ['MCART_XLS_CATALOG_QUANTITY_TRACE'] = "Flag (Y/N/D)* \"enable quantitative accounting\" (previous name \"to reduce the quantity when ordering\")";
$MESS ['MCART_XLS_CATALOG_BASE_PRICE'] = "Base price";
$MESS ['MCART_XLS_CATALOG_BASE_PRICE_CURRENCY'] = "Base price currency (by default - base)";
$MESS ['MCART_XLS_CATALOG_PURCHASING_PRICE'] = "Purchasing price";
$MESS ['MCART_XLS_CATALOG_PURCHASING_CURRENCY'] = "Purchasing price currency (by default - base)";
$MESS ['MCART_XLS_CATALOG_VAT_ID'] = "VAT rates ID";
$MESS ['MCART_XLS_CATALOG_VAT_RATE'] = "VAT rates, %";
$MESS ['MCART_XLS_CATALOG_VAT_INCLUDED'] = "Flag (Y/N) Is VAT included in the price";
$MESS ['MCART_XLS_CATALOG_MEASURE'] = "Units ID";