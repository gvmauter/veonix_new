﻿<?
$MESS ['MCART_XLS_PROFILE_ID'] = "Profile ID";
$MESS ['MCART_XLS_PROFILE_NAME'] = "Profile name";
$MESS ['MCART_XLS_PROFILE_FILE'] = "File";
$MESS ['MCART_XLS_PROFILE_FILE_HEADERS'] = "Headers from the file";
$MESS ['MCART_XLS_PROFILE_MAIL_FILTER_ID'] = "Mail processing rule";
$MESS ['MCART_XLS_PROFILE_IBLOCK_ID'] = "Infoblock ID";

$MESS ['MCART_XLS_PROFILE_QUANTITY_ELEMENTS_IMPORTED_PER_STEP'] = "The quantity of elements, processed per import step";

$MESS ['MCART_XLS_PROFILE_ONLY_UPDATE'] = "Only update elements (don't create)";

$MESS ['MCART_XLS_PROFILE_DEACTIVATE_IF_NEW'] = "Deactivate new elements";
$MESS ['MCART_XLS_PROFILE_SKU_CODE'] = "Trade offer code";
$MESS ['MCART_XLS_PROFILE_DEACTIVATE_IF_QUANTITY_0'] = "Deactivate an element, if the goods are out of stock";
$MESS ['MCART_XLS_PROFILE_DEACTIVATE_IF_PRICE_0'] = "Deactivate an element, if the price is zero";
$MESS ['MCART_XLS_PROFILE_DEACTIVATE_ELEMENT_IF_NOT_IN_FILE'] = "Deactivate elements that are not in the file (not yet implemented)";

$MESS ['MCART_XLS_PROFILE_ACTIVATE_IF_QUANTITY_AND_PRICE_NOT_0'] = "Activate an element if the price is not zero and the goods are in stock";

$MESS ['MCART_XLS_PROFILE_IBLOCK_SECTION_ID_FOR_NEW'] = "Section ID for new infoblock elements (by default is root)";

$MESS ['MCART_XLS_PROFILE_HEADER_ROW'] = "Row with the headers";
$MESS ['MCART_XLS_PROFILE_START_ROW'] = "First row with the data";
$MESS ['MCART_XLS_PROFILE_END_ROW'] = "Last row with the data";
