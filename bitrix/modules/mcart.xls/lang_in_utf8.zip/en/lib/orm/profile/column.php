﻿<?
$MESS ['MCART_XLS_PROFILE_COLUMN_PROFILE_ID'] = "Profile ID";
$MESS ['MCART_XLS_PROFILE_COLUMN_COLUMN'] = "Column in file";
$MESS ['MCART_XLS_PROFILE_COLUMN_SAVE_IN_PREF'] = "Value storage location (field, property, catalogue, etc.)";
$MESS ['MCART_XLS_PROFILE_COLUMN_SAVE_IN'] = "Field/property of the element";
$MESS ['MCART_XLS_PROFILE_COLUMN_HANDLER'] = "Transformation";
$MESS ['MCART_XLS_PROFILE_COLUMN_DO_NOT_IMPORT_ROW_IF_EMPTY'] = "Don't import the row if this cell is empty";
$MESS ['MCART_XLS_PROFILE_COLUMN_IS_IDENTIFY_ELEMENT'] = "Unique identifier of the item.";
