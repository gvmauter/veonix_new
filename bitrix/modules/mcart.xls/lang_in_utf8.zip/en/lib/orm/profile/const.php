﻿<?
$MESS ['MCART_XLS_PROFILE_CONST_PROFILE_ID'] = "Profile ID";
$MESS ['MCART_XLS_PROFILE_CONST_SAVE_IN_PREF'] = "Value storage location (field, property, catalogue, etc.)";
$MESS ['MCART_XLS_PROFILE_CONST_SAVE_IN'] = "Field/property of the element/goods";
$MESS ['MCART_XLS_PROFILE_CONST_VALUE'] = "Constant";


