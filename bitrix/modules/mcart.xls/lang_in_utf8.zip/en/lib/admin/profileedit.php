﻿<?
$MESS["MCART_XLS_PROFILE_NEW_TITLE"] = "Adding profile";
$MESS["MCART_XLS_PROFILE_EDIT_TITLE"] = "Edit profile";

$MESS ['MCART_XLS_PROFILE_REQUIRED_FIELDS'] = "Required fields are marked in <b>bold</b>";

$MESS ['MCART_XLS_PROFILE_END_ROW_TOOLTIP'] = "If not specified, to the end of the sheet";
$MESS ['MCART_XLS_PROFILE_ACTIVATE_IF_QUANTITY_AND_PRICE_NOT_0_TOOLTIP'] = "Activate an element, if price and quantity are not zero (quantity is more than zero or quantitative accounting is disabled)";
$MESS ['MCART_XLS_PROFILE_DEACTIVATE_IF_QUANTITY_0_TOOLTIP'] = "That is, if the quantity is zero and quantitative accounting is enabled";

$MESS ['MCART_XLS_PROFILE_STEP1_HEAD3'] = "Constants";
$MESS ['MCART_XLS_PROFILE_STEP1_CONST_HEAD1'] = "Constant";
$MESS ['MCART_XLS_PROFILE_STEP1_CONST_HEAD2'] = "Field/property of the infoblock";

$MESS ['MCART_XLS_PROFILE_ERROR_NAME'] = "Enter the name";
$MESS ['MCART_XLS_PROFILE_ERROR_FILE'] = "Add the file *.xlsx";
$MESS ['MCART_XLS_PROFILE_ERROR_IBLOCK_ID'] = "Specify the infoblock";
