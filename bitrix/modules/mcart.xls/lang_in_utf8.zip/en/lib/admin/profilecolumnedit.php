﻿<?
$MESS ['MCART_XLS_TITLE_PREF'] = "Column mappings to profile";
$MESS ['MCART_XLS_CUSTOM_FIELDS_HEAD'] = "Additional settings";
$MESS ['MCART_XLS_CUSTOM_FIELDS_HEAD_TOOLTIP'] = "will be passed to event processors";
