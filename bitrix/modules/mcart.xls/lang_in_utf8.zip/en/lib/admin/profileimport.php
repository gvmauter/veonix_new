﻿<?
$MESS ['MCART_XLS_TITLE_PREF'] = "Import by the profile";
$MESS ['MCART_XLS_IMPORT__PROCESSED_ROWS'] = "Rows processed";
$MESS ['MCART_XLS_IMPORT__ADDED_ELEMENTS'] = "Elements added";
$MESS ['MCART_XLS_IMPORT__UPDATED_ELEMENTS'] = "Elements updated";
$MESS ['MCART_XLS_PROFILE_ERROR_FILE'] = "Add the file *.xlsx";