﻿<?
$MESS ['MCART_XLS_TITLE_PREF'] = "Column mappings to profile";
