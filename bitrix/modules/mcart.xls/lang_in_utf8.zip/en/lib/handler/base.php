﻿<?php

$MESS ['MCART_XLS_HANDLER_DATE'] = "Date";

$MESS ['MCART_XLS_HANDLER_DATETIME'] = "Date and time";

$MESS ['MCART_XLS_HANDLER_PICTURE'] = "Picture";

$MESS ['MCART_XLS_HANDLER_URL'] = "URL";
$MESS ['MCART_XLS_HANDLER_URL__TEST_REQUIRED'] = "Test (required)";
$MESS ['MCART_XLS_HANDLER_URL__TEST'] = "Test";
$MESS ['MCART_XLS_HANDLER_URL__TEST_LIST_REQUIRED'] = "Test of the list (required)";
$MESS ['MCART_XLS_HANDLER_URL__TEST_LIST'] = "Test of the list";
