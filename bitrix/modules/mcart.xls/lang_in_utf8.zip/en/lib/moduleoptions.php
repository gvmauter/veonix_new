﻿<?
$MESS['MCART_XLS__PROFILE__USERS_GROUPS'] = "Simplified mode for groups";
$MESS['MCART_XLS__PROFILE__USERS_GROUPS_TOOLTIP'] = "For the specified user groups, preset the following parameters, and don't let them to change it.";
$MESS['MCART_XLS__PROFILE__END_ROW_TOOLTIP'] = "If not specified, to the end of the sheet";


