﻿<?
$MESS ['MCART_XLS_IMPORT_COMPLETED'] = "Import is completed";
$MESS ['MCART_XLS_IMPORT_ERROR__PROFILE_ID_0'] = 'The profile is not specified';
$MESS ['MCART_XLS_IMPORT_ERROR__PROFILE_NOT_FOUND'] = 'The profile is not found';
$MESS ['MCART_XLS_IMPORT_ERROR__PROFILE_COLUMNS_NOT_FOUND'] = 'Column mappings were not found';
$MESS ['MCART_XLS_IMPORT_ERROR__PROFILE_IDENTIFY_ELEMENT_NOT_FOUND'] = 'None of the column mappings were marked as "Unique identifier of the item"';
