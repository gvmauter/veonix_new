<?
$MESS ['MCART_XLS_PROFILE_REQUIRED_FIELDS'] = "Pflichtfelder sind <b>fett</b> hervorgehoben";

$MESS ['MCART_XLS_PROFILE_END_ROW_TOOLTIP'] = "Wenn nicht angegeben, bis zum Ende des Blattes";

$MESS ['MCART_XLS_PROFILE_ACTIVATE_IF_QUANTITY_AND_PRICE_NOT_0_TOOLTIP'] = "Aktivieren den Element, wenn der Preis nicht null ist und das Produkt auf Lager ist (d. h. die Menge ist größer als null, oder die Bestandskontrolle ist deaktiviert)";
$MESS ['MCART_XLS_PROFILE_DEACTIVATE_IF_QUANTITY_0_TOOLTIP'] = "d. h., wenn die Zahl Null ist";

$MESS ['MCART_XLS_PROFILE_STEP1_HEAD3'] = "Konstanten";
$MESS ['MCART_XLS_PROFILE_STEP1_CONST_HEAD1'] = "Konstante";
$MESS ['MCART_XLS_PROFILE_STEP1_CONST_HEAD2'] = "Feld/Eigenschaft des Infoblocks";

$MESS ['MCART_XLS_PROFILE_NEXT'] = "Weiter";
$MESS ['MCART_XLS_PROFILE_CANCEL'] = "Abbrechen";

$MESS ['MCART_XLS_PROFILE_ERROR_NAME'] = "Geben Sie den Namen an";
$MESS ['MCART_XLS_PROFILE_ERROR_FILE'] = "Geben Sie die Datei an *.xlsx";
$MESS ['MCART_XLS_PROFILE_ERROR_IBLOCK_ID'] = "Geben Sie einen Infoblock an";
