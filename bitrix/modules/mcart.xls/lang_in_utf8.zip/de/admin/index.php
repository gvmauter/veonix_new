﻿<?
$MESS ['MCART_XLS_COL_NAME'] = "Profilname";
$MESS ['MCART_XLS_COL_IBLOCK'] = "Infoblock";
