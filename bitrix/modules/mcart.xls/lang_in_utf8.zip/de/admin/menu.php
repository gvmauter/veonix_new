﻿<?
$MESS ['MCART_XLS_TITLE'] = "Importieren aus Excel";
