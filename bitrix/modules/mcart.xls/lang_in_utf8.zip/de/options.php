﻿<?
$MESS["MCART_XLS__OPTIONS__SAVE"] = "Speichern";
$MESS["MCART_XLS__OPTIONS__RESET"] = "Zurücksetzen";
$MESS["MCART_XLS__OPTIONS__RESTORE_DEFAULTS"] = "Voreinstellung";
$MESS['MCART_XLS__OPTIONS__HINT_RESTORE_DEFAULTS_WARNING'] = "Beachtung! Alle Einstellungen werden mit den Standardwerten überschrieben. Fortsetzen?";