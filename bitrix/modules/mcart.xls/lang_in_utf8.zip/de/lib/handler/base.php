﻿<?php

$MESS ['MCART_XLS_HANDLER_DATE'] = "Datum";

$MESS ['MCART_XLS_HANDLER_DATETIME'] = "Datum und Uhrzeit";

$MESS ['MCART_XLS_HANDLER_PICTURE'] = "Bild";

$MESS ['MCART_XLS_HANDLER_URL'] = "URL";
$MESS ['MCART_XLS_HANDLER_URL__TEST_REQUIRED'] = "Test (erforderlich)";
$MESS ['MCART_XLS_HANDLER_URL__TEST'] = "Test";
$MESS ['MCART_XLS_HANDLER_URL__TEST_LIST_REQUIRED'] = "Test der Liste (erforderlich)";
$MESS ['MCART_XLS_HANDLER_URL__TEST_LIST'] = "Test der Liste";
