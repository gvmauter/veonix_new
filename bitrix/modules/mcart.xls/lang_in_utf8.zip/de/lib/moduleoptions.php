﻿<?
$MESS['MCART_XLS__PROFILE__USERS_GROUPS'] = "Vereinfachter Modus für Gruppen";
$MESS['MCART_XLS__PROFILE__USERS_GROUPS_TOOLTIP'] = "Stellen für die angegebenen Benutzergruppen die folgenden Parameter ein und lassen sie diese nicht ändern.";
$MESS['MCART_XLS__PROFILE__END_ROW_TOOLTIP'] = "Wenn nicht angegeben, bis zum Ende des Blattes";


