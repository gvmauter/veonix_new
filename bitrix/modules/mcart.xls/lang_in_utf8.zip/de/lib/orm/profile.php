﻿<?
$MESS ['MCART_XLS_PROFILE_ID'] = "Profil ID";
$MESS ['MCART_XLS_PROFILE_NAME'] = "Profilname";
$MESS ['MCART_XLS_PROFILE_FILE'] = "Datei";
$MESS ['MCART_XLS_PROFILE_FILE_HEADERS'] = "Kopfzeile aus der Datei";
$MESS ['MCART_XLS_PROFILE_MAIL_FILTER_ID'] = "E-Mail-Verarbeitung Regel";
$MESS ['MCART_XLS_PROFILE_IBLOCK_ID'] = "Infoblock ID";

$MESS ['MCART_XLS_PROFILE_QUANTITY_ELEMENTS_IMPORTED_PER_STEP'] = "Die Menge der Elemente, verarbeitet pro importschritt";

$MESS ['MCART_XLS_PROFILE_ONLY_UPDATE'] = "Nur die Elemente aktualisieren (nicht erstellen)";

$MESS ['MCART_XLS_PROFILE_DEACTIVATE_IF_NEW'] = "Neue Elemente deaktivieren";
$MESS ['MCART_XLS_PROFILE_SKU_CODE'] = "Code für Handelsangebote";
$MESS ['MCART_XLS_PROFILE_DEACTIVATE_IF_QUANTITY_0'] = "Deaktivieren ein Element, wenn die Ware nicht vorrätig ist";
$MESS ['MCART_XLS_PROFILE_DEACTIVATE_IF_PRICE_0'] = "Deaktivieren ein Element, wenn der Preis Null ist";
$MESS ['MCART_XLS_PROFILE_DEACTIVATE_ELEMENT_IF_NOT_IN_FILE'] = "Elemente deaktivieren, die nicht in der Datei sind (noch nicht implementiert)";

$MESS ['MCART_XLS_PROFILE_ACTIVATE_IF_QUANTITY_AND_PRICE_NOT_0'] = "Aktivieren ein Element, wenn der Preis nicht Null ist und die Waren auf Lager sind";

$MESS ['MCART_XLS_PROFILE_IBLOCK_SECTION_ID_FOR_NEW'] = "Abschnitts-ID für neue Infoblock-Elemente (standardmäßig - root)";

$MESS ['MCART_XLS_PROFILE_HEADER_ROW'] = "Zeile mit den Kopfzeilen";
$MESS ['MCART_XLS_PROFILE_START_ROW'] = "Erste Zeile mit den Daten";
$MESS ['MCART_XLS_PROFILE_END_ROW'] = "Letzte Zeile mit den Daten";
