﻿<?
$MESS ['MCART_XLS_PROFILE_COLUMN_PROFILE_ID'] = "Profil ID";
$MESS ['MCART_XLS_PROFILE_COLUMN_COLUMN'] = "Spalte in der Datei";
$MESS ['MCART_XLS_PROFILE_COLUMN_SAVE_IN_PREF'] = "Wertspeicherort (feld, Eigentum, Katalog, usw.)";
$MESS ['MCART_XLS_PROFILE_COLUMN_SAVE_IN'] = "Feld/Eigentum des Elements";
$MESS ['MCART_XLS_PROFILE_COLUMN_HANDLER'] = "Transformation";
$MESS ['MCART_XLS_PROFILE_COLUMN_DO_NOT_IMPORT_ROW_IF_EMPTY'] = "Importieren die Zeile nicht, wenn diese Zelle leer ist";
$MESS ['MCART_XLS_PROFILE_COLUMN_IS_IDENTIFY_ELEMENT'] = "Eindeutige Kennung des Elements";
