﻿<?
$MESS ['MCART_XLS_PROFILE_CONST_PROFILE_ID'] = "Profil ID";
$MESS ['MCART_XLS_PROFILE_CONST_SAVE_IN_PREF'] = "Wertspeicherort (feld, Eigentum, Katalog, usw.)";
$MESS ['MCART_XLS_PROFILE_CONST_SAVE_IN'] = "Feld/Eigentum des Elements/von waren";
$MESS ['MCART_XLS_PROFILE_CONST_VALUE'] = "Konstant";


