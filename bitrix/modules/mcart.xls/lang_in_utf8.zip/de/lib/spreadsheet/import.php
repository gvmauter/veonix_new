﻿<?
$MESS ['MCART_XLS_IMPORT_COMPLETED'] = "Import ist abgeschlossen";
$MESS ['MCART_XLS_IMPORT_ERROR__PROFILE_ID_0'] = 'Kein profil angegeben';
$MESS ['MCART_XLS_IMPORT_ERROR__PROFILE_NOT_FOUND'] = 'Profil nicht gefunden';
$MESS ['MCART_XLS_IMPORT_ERROR__PROFILE_COLUMNS_NOT_FOUND'] = 'Es wurden keine spaltenzuordnungen gefunden';
$MESS ['MCART_XLS_IMPORT_ERROR__PROFILE_IDENTIFY_ELEMENT_NOT_FOUND'] = 'Keine der spaltenzuordnungen wurde als "Eindeutige Kennung des Elements" markiert';
