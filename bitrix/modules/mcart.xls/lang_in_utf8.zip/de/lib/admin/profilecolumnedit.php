﻿<?
$MESS ['MCART_XLS_TITLE_PREF'] = "Passend zum Profil";
$MESS ['MCART_XLS_CUSTOM_FIELDS_HEAD'] = "Zusätzliche Einstellungen";
$MESS ['MCART_XLS_CUSTOM_FIELDS_HEAD_TOOLTIP'] = "wird an ereignis Prozessoren übergeben";
