﻿<?
$MESS["MCART_XLS_PROFILE_NEW_TITLE"] = "Profil hinzufügen";
$MESS["MCART_XLS_PROFILE_EDIT_TITLE"] = "Profil bearbeiten";

$MESS ['MCART_XLS_PROFILE_REQUIRED_FIELDS'] = "Erforderliche Felder sind <b>fett</b> markiert";

$MESS ['MCART_XLS_PROFILE_END_ROW_TOOLTIP'] = "Wenn nicht angegeben, bis zum Ende des Blattes";
$MESS ['MCART_XLS_PROFILE_ACTIVATE_IF_QUANTITY_AND_PRICE_NOT_0_TOOLTIP'] = "Aktivieren ein Element, wenn Preis und Menge nicht Null sind (Menge ist größer als Null oder quantitative Abrechnung ist deaktiviert)";
$MESS ['MCART_XLS_PROFILE_DEACTIVATE_IF_QUANTITY_0_TOOLTIP'] = "Das heißt, wenn die Menge Null ist und die quantitative Abrechnung aktiviert ist";

$MESS ['MCART_XLS_PROFILE_STEP1_HEAD3'] = "Konstanten";
$MESS ['MCART_XLS_PROFILE_STEP1_CONST_HEAD1'] = "Konstant";
$MESS ['MCART_XLS_PROFILE_STEP1_CONST_HEAD2'] = "Feld/Eigentum des Infoblocks";

$MESS ['MCART_XLS_PROFILE_ERROR_NAME'] = "Geben den Namen ein";
$MESS ['MCART_XLS_PROFILE_ERROR_FILE'] = "Fügen die Datei *.xlsx hinzu ";
$MESS ['MCART_XLS_PROFILE_ERROR_IBLOCK_ID'] = "Geben den Infoblock an";
