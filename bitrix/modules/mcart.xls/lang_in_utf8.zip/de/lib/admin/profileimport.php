﻿<?
$MESS ['MCART_XLS_TITLE_PREF'] = "Importieren über das Profil";
$MESS ['MCART_XLS_IMPORT__PROCESSED_ROWS'] = "Zeilen verarbeitet";
$MESS ['MCART_XLS_IMPORT__ADDED_ELEMENTS'] = "Elemente hinzugefügt";
$MESS ['MCART_XLS_IMPORT__UPDATED_ELEMENTS'] = "Elemente aktualisiert";
$MESS ['MCART_XLS_PROFILE_ERROR_FILE'] = "Fügen die Datei *.xlsx hinzu";